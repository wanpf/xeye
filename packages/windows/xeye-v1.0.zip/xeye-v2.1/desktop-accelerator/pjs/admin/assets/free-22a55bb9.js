const e="/demo/images/landing/free.svg";export{e as _};
